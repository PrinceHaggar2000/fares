
package Model;

import java.time.LocalDateTime;

/**
 *
 * @author princehaggar
 */
public class Parking {
    private int OwnerID;
    private String FirstName;
    private String LastName;
    private String PhoneNumber ;
    private String Sex;
    private int VehicleID;
    private String VehicleType;
    private String LicensePlate;
    private String Color;
    private String Make;
    private LocalDateTime DateOfEntry; 

    public Parking() {
    }



    public Parking(int OwnerID, String FirstName, String LastName, String PhoneNumber, String Sex, int VehicleID, String VehicleType, String LicencePlate, String Color, String Make, LocalDateTime DateOfEntry) {
        this.OwnerID = OwnerID;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.PhoneNumber = PhoneNumber;
        this.Sex = Sex;
        this.VehicleID = VehicleID;
        this.VehicleType = VehicleType;
        this.LicensePlate = LicencePlate;
        this.Color = Color;
        this.Make = Make;
        this.DateOfEntry = DateOfEntry;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getSex() {
        return Sex;
    }

    public void setSex(String Sex) {
        this.Sex = Sex;
    }

    public String getVehicleType() {
        return VehicleType;
    }

    public void setVehicleType(String VehicleType) {
        this.VehicleType = VehicleType;
    }

    public String getLicensePlate() {
        return LicensePlate;
    }

    public void setLicensePlate(String LicensePlate) {
        this.LicensePlate = LicensePlate;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getMake() {
        return Make;
    }

    public void setMake(String Make) {
        this.Make = Make;
    }

    public LocalDateTime getDateOfEntry() {
        return DateOfEntry;
    }

    public void setDateOfEntry(LocalDateTime DateOfEntry) {
        this.DateOfEntry = DateOfEntry;
    }

    public int getOwnerID() {
        return OwnerID;
    }

    public void setOwnerID(int OwnerID) {
        this.OwnerID = OwnerID;
    }

    public int getVehicleID() {
        return VehicleID;
    }

    public void setVehicleID(int VehicleID) {
        this.VehicleID = VehicleID;
    }

   

    
    

}
