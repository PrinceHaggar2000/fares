
package Dao;
import Model.Parking;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
/**
 *
 * @author princehaggar
 */
public class ParkingDao {
    String dbUrl="jdbc:mysql://localhost:3306/Parking_management_system_db";
    String username="root";
    String password="Gentleman2.0";

    public ParkingDao() {
    }
   //---------------------------------------------------------------------------- 
   //Record
   public String Record(Parking parking) {
    String Sql1 = "INSERT INTO Owner(OwnerID, FirstName, LastName, PhoneNumber,Sex) VALUES (?,?,?,?,?)";
    String Sql2 = "INSERT INTO VehicleInfos(VehicleID , VehicleType, LicensePlate, Make, Color, DateOfEntry) VALUES (?,?,?,?,?,?)";
    try (Connection con = DriverManager.getConnection(dbUrl, username, password);
         PreparedStatement pst = con.prepareStatement(Sql1);
         PreparedStatement ps = con.prepareStatement(Sql2)) {
        // Insert data into the Owner table
        pst.setInt(1,    parking.getOwnerID());
        pst.setString(2, parking.getFirstName());
        pst.setString(3, parking.getLastName());
        pst.setString(4, parking.getPhoneNumber());
        pst.setString(5, parking.getSex());
        pst.executeUpdate();
        // Insert data into the VehicleInfos table
        ps.setInt(1,    parking.getVehicleID());
        ps.setString(2, parking.getVehicleType());
        ps.setString(3, parking.getLicensePlate());
        ps.setString(4, parking.getMake());
        ps.setString(5, parking.getColor());
        ps.setObject(6, parking.getDateOfEntry());
        ps.executeUpdate();
        return "Data inserted successfully for both Owner and VehicleInfos";
    } catch (Exception e) {
        e.printStackTrace();
        return "Server Error: " + e.getMessage();
    }
}
//---------------------------------------------------------------------------- 
// Update
  public String Update(Parking parking) {
    String ownerUpdateSql = "UPDATE Owner SET FirstName = ?, LastName = ?, PhoneNumber = ?, Sex = ? WHERE OwnerID = ?";
    String vehicleUpdateSql = "UPDATE VehicleInfos SET VehicleType = ?, LicensePlate = ? ,Make = ? , Color = ?, DateOfEntry = ? WHERE VehicleID = ?";
    try (Connection con = DriverManager.getConnection(dbUrl, username, password);
         PreparedStatement ownerUpdatePstmt = con.prepareStatement(ownerUpdateSql);
         PreparedStatement vehicleUpdatePstmt = con.prepareStatement(vehicleUpdateSql)) {
        // Update owner information
        ownerUpdatePstmt.setString(1, parking.getFirstName());
        ownerUpdatePstmt.setString(2, parking.getLastName());
        ownerUpdatePstmt.setString(3, parking.getPhoneNumber());
        ownerUpdatePstmt.setString(4, parking.getSex());
        ownerUpdatePstmt.setInt(5, parking.getOwnerID());
        int ownerRowsAffected = ownerUpdatePstmt.executeUpdate();
        // Update vehicle information
        vehicleUpdatePstmt.setString(1, parking.getVehicleType());
        vehicleUpdatePstmt.setString(2, parking.getLicensePlate());
        vehicleUpdatePstmt.setString(3, parking.getMake());
        vehicleUpdatePstmt.setString(4, parking.getColor());
        vehicleUpdatePstmt.setObject(5, parking.getDateOfEntry());
        vehicleUpdatePstmt.setInt(6, parking.getVehicleID());
        int vehicleRowsAffected = vehicleUpdatePstmt.executeUpdate();
        if (ownerRowsAffected >= 1 && vehicleRowsAffected >= 1) {
            return "Data updated successfully for both Owner and VehicleInfos";
        } else {
            return "Data not updated, please check for errors !!!";
        }
    } catch (Exception e) {
        e.printStackTrace();
        return "Server Error: " + e.getMessage();
    }
}
 //---------------------------------------------------------------------------- 
    // - Deleting
 public void Delete(int ownerID, int vehicleID) {
    try {
        Connection con = DriverManager.getConnection(dbUrl, username, password);
        // Delete the owner record
        String ownerSql = "DELETE FROM Owner WHERE OwnerID = ?";
        PreparedStatement ownerPst = con.prepareStatement(ownerSql);
        ownerPst.setInt(1, ownerID);
        int ownerRowsDeleted = ownerPst.executeUpdate();
        // Delete the vehicle record
        String vehicleSql = "DELETE FROM VehicleInfos WHERE VehicleID = ?";
        PreparedStatement vehiclePst = con.prepareStatement(vehicleSql);
        vehiclePst.setInt(1, vehicleID);
        int vehicleRowsDeleted = vehiclePst.executeUpdate();
        con.close();
        if (ownerRowsDeleted > 0 && vehicleRowsDeleted > 0) {
            System.out.println("Records deleted successfully from both tables.");
        } else {
            System.out.println("Records not found or deleted.");
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
}
 //---------------------------------------------------------------------------- 
 //Searching 
public Parking search(Parking parking) {
    try {
        Connection con = DriverManager.getConnection(dbUrl, username, password);

        // Retrieve owner information from the Owner table
        String ownerSql = "SELECT * FROM Owner WHERE OwnerID=?";
        PreparedStatement ownerPst = con.prepareStatement(ownerSql);
        ownerPst.setInt(1, parking.getOwnerID());
        ResultSet ownerRs = ownerPst.executeQuery();
        boolean flag = false;
        while (ownerRs.next()) {
            // Set owner information
            parking.setOwnerID(ownerRs.getInt("OwnerID"));
            parking.setFirstName(ownerRs.getString("FirstName"));
            parking.setLastName(ownerRs.getString("LastName"));
            parking.setPhoneNumber(ownerRs.getString("PhoneNumber"));
            parking.setSex(ownerRs.getString("Sex"));
            String vehicleSql = "SELECT * FROM VehicleInfos WHERE VehicleID=?";
            PreparedStatement vehiclePst = con.prepareStatement(vehicleSql);
            vehiclePst.setInt(1, parking.getVehicleID());
            ResultSet vehicleRs = vehiclePst.executeQuery();
            if (vehicleRs.next()) {
                // Set vehicle information
                parking.setVehicleID(vehicleRs.getInt("VehicleID"));
                parking.setVehicleType(vehicleRs.getString("VehicleType"));
                parking.setLicensePlate(vehicleRs.getString("LicensePlate"));
                parking.setMake(vehicleRs.getString("Make"));
                parking.setColor(vehicleRs.getString("Color"));
                parking.setDateOfEntry(vehicleRs.getObject("DateOfEntry", LocalDateTime.class));
                flag = true;
            }
        }
        con.close();
        if (flag) {
            return parking;
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return null;
}
 //---------------------------------------------------------------------------- 
// List
public List<Parking> Owner(){
    List<Parking> Owner = new ArrayList<>();
    try {
        Connection con = DriverManager.getConnection(dbUrl, username, password);
        // Retrieve records from the Owner table
        String sql1 = "SELECT * FROM Owner";
        PreparedStatement pst = con.prepareStatement(sql1);
        ResultSet rs1 = pst.executeQuery();
        while (rs1.next()) {
            Parking parking = new Parking();
            parking.setOwnerID(rs1.getInt("OwnerID"));
            parking.setFirstName(rs1.getString("FirstName"));
            parking.setLastName(rs1.getString("LastName"));
            parking.setPhoneNumber(rs1.getString("PhoneNumber"));
            parking.setSex(rs1.getString("Sex"));
            Owner.add(parking);
        }
        con.close();
         return Owner;
    }catch (Exception ex){
        ex.printStackTrace();
    }
    return null;
    }

public List<Parking> vehicle(){
    List<Parking> vehicle = new ArrayList<>();
    try {  
        Connection con = DriverManager.getConnection(dbUrl, username, password);
        // Retrieve records from the VehicleInfos table
        String sql2 = "SELECT * FROM VehicleInfos";
        PreparedStatement ps = con.prepareStatement(sql2);
        ResultSet rs2 = ps.executeQuery();

        while (rs2.next()) {
            Parking parking = new Parking();
            parking.setVehicleID(rs2.getInt("VehicleID"));
            parking.setVehicleType(rs2.getString("VehicleType"));
            parking.setLicensePlate(rs2.getString("LicensePlate"));
              parking.setMake(rs2.getString("Make"));
            parking.setColor(rs2.getString("Color"));
            parking.setDateOfEntry((LocalDateTime) rs2.getObject("DateOfEntry"));
            vehicle.add(parking);
        }
        con.close();
         return vehicle;
    } catch (Exception ex) {
        ex.printStackTrace();
    }
return null;
}
   
}
  

