// login.js
document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Check username and password (replace with your actual validation logic)
    if (username === '@haggar' && password === 'prince66') {
        // Redirect to the registration page
        window.location.href = 'RegistrationPage.html';
    } else {
        // Display an error message or handle the incorrect login scenario
        alert('Incorrect username or password. Please try again.');
    }
});
